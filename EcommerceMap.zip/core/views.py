from django.shortcuts import render

# Create your views here.
from rest_framework import generics
from .models import Server, Layer
from .serializers import ServerSerializer, LayerSerializer


def index(request):
    return render(request, 'index.html')


class ServerListAPIView(generics.ListAPIView):
    queryset = Server.objects.all()
    serializer_class = ServerSerializer


class LayerListAPIView(generics.ListAPIView):
    queryset = Layer.objects.all()
    serializer_class = LayerSerializer
