from django.apps import AppConfig


class ConnectsConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'connects'
